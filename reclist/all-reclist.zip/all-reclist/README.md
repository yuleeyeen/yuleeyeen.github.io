# biao-utau-reclist
/1/some-utau-reclist
/2/Internally, there are some reclists, and some authors do not allow them to be assigned arbitrarily, but for ease of use, I did it anyway
/3/There are Chinese, English, Korean, Japanese, Cantonese, Shanghainese, and some special comment files will be updated or recorded in the file
/4/Most of the ones marked all are made or modified by me (yuleeyeen), and the same goes for those marked yly or yuleeyeen. Some are unmarked, but they are also made and modified by me
/5/I welcome everyone to make it complete, and to use it
/6/I welcome the creation of plugins to use them
---yuleeyeen/yuleeyeenP
___
___
___
_Say it a second time_
___
/1/some-utau-reclist
/2/Internally, there are some reclists, and some authors do not allow them to be assigned arbitrarily, but for ease of use, I did it anyway
/3/There are Chinese, English, Korean, Japanese, Cantonese, Shanghainese, and some special comment files will be updated or recorded in the file
/4/Most of the ones marked all are made or modified by me (yuleeyeen), and the same goes for those marked yly or yuleeyeen. Some are unmarked, but they are also made and modified by me
/5/I welcome everyone to make it complete, and to use it
/6/I welcome the creation of plugins to use them
---yuleeyeen/yuleeyeenP
___To communicate, please contact me on bilibili_(yuleeyeenP) or Xiaohongshu_(search for yuleeyeen), or send a message to  wangyi-email_18316001770@163.com
